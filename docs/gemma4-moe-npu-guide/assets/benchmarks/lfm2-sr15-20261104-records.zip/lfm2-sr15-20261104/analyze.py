"""Validate and summarize the LFM sweep without changing the guide."""
import csv
import hashlib
import json
import shlex
import statistics
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
repo = Path('/home/jungone-lee/workspace/nntrainer')
rows = json.loads((out / 'results.json').read_text())
summary = json.loads((out / 'summary.json').read_text())
manifest = json.loads((out / 'manifest.json').read_text())
measured = [r for r in rows if not r['warmup']]
assert len(rows) == 13 and len(measured) == 12
for r in rows:
    assert r['returncode'] == 0
    assert r['input_ids_match'] and r['actual_input_tokens'] == r['input_requested']
    assert r['actual_output_tokens'] == 128 and r['decode_tokens'] == 127
    assert r['htp_resident_graph'] and 'CONV1D_GATE' in r['resident_ops']
    assert r['lfm2_cli_defaults_active'] and not r['cpu_fallback']
    assert r['peak_memory_kib'] == r['honest_peak_kib']
    assert r['thermal_before']['status'] == 0
    assert r['thermal_before']['celsius']['AP'] <= 34
    assert r['thermal_before']['celsius']['SKIN'] <= 35.5
for s in summary:
    selected = [r for r in measured if r['actual_input_tokens'] == s['input_tokens']]
    assert len(selected) == 3
    assert s['output_ids_identical'] == (len({r['output_ids_sha256'] for r in selected}) == 1)
    for key in ['prefill_tps', 'decode_tps', 'peak_memory_kib']:
        assert s[key]['median'] == statistics.median(r[key] for r in selected)

adb = ['adb', '-s', 'R3CY70LV96T']
sidecars = ['config.json', 'nntr_config.json', 'generation_config.json',
            'tokenizer.json', 'tokenizer_config.json', 'chat_template.jinja',
            'conversion_report.json']
manifest['pack_sidecar_sha256'] = {}
for name in sidecars:
    digest = subprocess.check_output(adb + ['shell', 'sha256sum ' + shlex.quote(manifest['model_pack'] + '/' + name)], text=True).split()[0]
    manifest['pack_sidecar_sha256'][name] = digest
    if (out / ('deployed-' + name)).exists():
        assert hashlib.sha256((out / ('deployed-' + name)).read_bytes()).hexdigest() == digest
manifest['deployed_configs_unchanged_after_sweep'] = True
manifest['completed_measured_runs'] = len(measured)
manifest['all_token_counts_verified'] = True
manifest['thermal_observed_c'] = {
    phase: {sensor: {'min': min(r['thermal_' + phase]['celsius'][sensor] for r in measured),
                     'max': max(r['thermal_' + phase]['celsius'][sensor] for r in measured)}
            for sensor in ['AP', 'SKIN']}
    for phase in ['before', 'after']
}
baseline = json.loads((out / 'guide-before-sha256.json').read_text())
for name, digest in baseline.items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest, name + ' changed'
manifest['guide_files_unchanged'] = len(baseline)
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

fields = ['tag', 'warmup', 'repeat', 'input_tokens', 'output_tokens', 'decode_steps',
          'prefill_tps', 'decode_tps', 'ttft_ms', 'prefill_ms', 'decode_ms',
          'peak_memory_kib', 'peak_memory_gib', 'ap_before_c', 'skin_before_c',
          'ap_after_c', 'skin_after_c', 'input_ids_match', 'output_ids_sha256']
with (out / 'runs.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for r in rows:
        item = {k: r[k] for k in ['tag', 'warmup', 'repeat', 'prefill_tps', 'decode_tps',
                                 'prefill_ms', 'decode_ms', 'peak_memory_kib',
                                 'input_ids_match', 'output_ids_sha256']}
        item.update(input_tokens=r['actual_input_tokens'], output_tokens=r['actual_output_tokens'],
                    decode_steps=r['decode_tokens'], ttft_ms=r['perf_split']['ttft_ms'],
                    peak_memory_gib=r['peak_memory_kib'] / 1048576)
        for phase in ['before', 'after']:
            for sensor in ['AP', 'SKIN']:
                item[sensor.lower() + '_' + phase + '_c'] = r['thermal_' + phase]['celsius'][sensor]
        writer.writerow(item)

lines = [
    '# LFM2 24B-A2B SR15 NPU measurement — 2026-11-04',
    '',
    'Measured on the same SM-S948U, Android 16 / SM8850 / Hexagon v81 phone as the Gemma4 sweep.',
    'The CLI and all seven runtime libraries match the Gemma4 measurement by SHA-256.',
    'The binary source commit is unverified; identities are recorded in manifest.json.',
    '',
    'Three fresh CLI processes per input length after one excluded 1K warm-up. Every measured',
    'input ID matched the prepared tokenizer IDs; every output contains exactly 128 IDs.',
    'Run order, USB connection, normal OS caches, eight threads, batch one, greedy decoding,',
    '16 resident experts per layer, init_seq_len=2048, max_seq_len=8704 and start-temperature',
    'limits match the Gemma4 sweep. AP must be ≤34 °C, skin ≤35.5 °C and thermal status 0;',
    'each run has at least 15 seconds of rest beforehand.',
    '',
    'Model-specific differences: LFM tokenizer/chat template, q8_row attention KV, EOS ID 7,',
    'and the automatic LFM2 SR15 CLI preset. Synthetic prompts use the same source paragraphs',
    'and summary request; text length differs because tokenizers differ. The isolated LFM',
    'configs raise the deployed init_seq_len from 64 to 2048 to match the Gemma4 benchmark.',
    'chat_input is removed from those copies so the exact sample_input is used. The original',
    'deployed pack and the documentation were not modified.',
    '',
    'Values below are medians of three runs; parentheses show min–max.',
    '',
    '| Input tokens | Prefill tok/s | Decode tok/s | TTFT s | Peak GiB |',
    '| --- | --- | --- | --- | --- |',
]
for s in summary:
    values = []
    for key, scale, digits in [('prefill_tps', 1, 1), ('decode_tps', 1, 2),
                               ('ttft_ms', 1000, 2), ('peak_memory_kib', 1048576, 3)]:
        m = s[key]
        values.append(f"{m['median']/scale:.{digits}f} ({m['min']/scale:.{digits}f}–{m['max']/scale:.{digits}f})")
    lines.append(f"| {s['input_tokens']:,} | " + ' | '.join(values) + ' |')
lines += [
    '',
    '128 outputs comprise the prefill token plus 127 decode steps. The CLI generation log',
    'therefore reports 127 tokens. Decode throughput uses those 127 steps, including the',
    'first decode step. TTFT is native PERF-SPLIT ttft_ms and excludes startup/model load.',
    'Peak memory is runtime-sampled RssAnon + accelerator, excluding file-backed page cache;',
    'divide runtime KiB by 1,048,576 for GiB. It is not total phone RAM usage.',
    '',
    'These synthetic short runs measure throughput, not task accuracy or sustained hot-device',
    'performance. Model architectures, active parameter counts and kernel presets differ.',
    '',
    f"Output IDs identical in all repeats at each length: {all(s['output_ids_identical'] for s in summary)}.",
    f"Unchanged guide files verified by SHA-256: {len(baseline)}.",
    '',
    'Files: summary.json, results.json, runs.csv and manifest.json; raw per-trial CLI logs,',
    'native token traces, configurations and before/after thermal readings; exact prompts',
    'and expected IDs. run.py performs the sweep; prepare_prompts.py uses tokenizers 0.22.1.',
]
(out / 'RESULTS.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
