# LFM2 24B-A2B SR15 NPU measurement — 2026-11-04

Measured on the same SM-S948U, Android 16 / SM8850 / Hexagon v81 phone as the Gemma4 sweep.
The CLI and all seven runtime libraries match the Gemma4 measurement by SHA-256.
The binary source commit is unverified; identities are recorded in manifest.json.

Three fresh CLI processes per input length after one excluded 1K warm-up. Every measured
input ID matched the prepared tokenizer IDs; every output contains exactly 128 IDs.
Run order, USB connection, normal OS caches, eight threads, batch one, greedy decoding,
16 resident experts per layer, init_seq_len=2048, max_seq_len=8704 and start-temperature
limits match the Gemma4 sweep. AP must be ≤34 °C, skin ≤35.5 °C and thermal status 0;
each run has at least 15 seconds of rest beforehand.

Model-specific differences: LFM tokenizer/chat template, q8_row attention KV, EOS ID 7,
and the automatic LFM2 SR15 CLI preset. Synthetic prompts use the same source paragraphs
and summary request; text length differs because tokenizers differ. The isolated LFM
configs raise the deployed init_seq_len from 64 to 2048 to match the Gemma4 benchmark.
chat_input is removed from those copies so the exact sample_input is used. The original
deployed pack and the documentation were not modified.

Values below are medians of three runs; parentheses show min–max.

| Input tokens | Prefill tok/s | Decode tok/s | TTFT s | Peak GiB |
| --- | --- | --- | --- | --- |
| 1,024 | 799.4 (761.9–826.5) | 18.60 (18.34–19.31) | 1.30 (1.26–1.37) | 2.146 (2.145–2.146) |
| 2,048 | 1083.0 (1083.0–1084.8) | 18.19 (18.04–18.33) | 1.91 (1.91–1.91) | 2.213 (2.213–2.229) |
| 4,096 | 768.8 (766.0–769.5) | 17.16 (17.11–17.16) | 5.35 (5.34–5.37) | 2.263 (2.263–2.267) |
| 8,192 | 571.5 (566.6–574.4) | 15.26 (15.19–15.29) | 14.36 (14.29–14.48) | 2.264 (2.264–2.266) |

128 outputs comprise the prefill token plus 127 decode steps. The CLI generation log
therefore reports 127 tokens. Decode throughput uses those 127 steps, including the
first decode step. TTFT is native PERF-SPLIT ttft_ms and excludes startup/model load.
Peak memory is runtime-sampled RssAnon + accelerator, excluding file-backed page cache;
divide runtime KiB by 1,048,576 for GiB. It is not total phone RAM usage.

These synthetic short runs measure throughput, not task accuracy or sustained hot-device
performance. Model architectures, active parameter counts and kernel presets differ.

Output IDs identical in all repeats at each length: True.
Unchanged guide files verified by SHA-256: 42.

Files: summary.json, results.json, runs.csv and manifest.json; raw per-trial CLI logs,
native token traces, configurations and before/after thermal readings; exact prompts
and expected IDs. run.py performs the sweep; prepare_prompts.py uses tokenizers 0.22.1.
