#!/usr/bin/env python3
"""Benchmark a deployed Gemma4 TL2 pack in isolated device directories.

Uses the existing runtime whose libraries match the installed Quick.AI APK.
Does not change the deployed model, app, or runtime. Prompts and expected IDs
must be present beside this script. Each trial is a fresh CLI process.
"""
import hashlib
import json
import re
import shlex
import statistics
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
ADB = ['adb', '-s', 'R3CY70LV96T']
PACK = '/sdcard/Download/aistudio-mobile/models/gemma4-26b-a4b-htp-w4a32'
SOURCE_RUNTIME = '/data/local/tmp/v4480_sync_1104/fix'
REMOTE = '/data/local/tmp/quickai_docs_benchmark_' + datetime.now().strftime('%Y%m%d_%H%M%S')
RUNTIME = REMOTE + '/runtime'
LIBS = ['libcausallm.so', 'libnntrainer.so', 'libccapi-nntrainer.so',
        'libquick_dot_ai_api.so', 'libnntr_hvx_skel.so', 'libsdkl.so', 'libc++_shared.so']

def shell(command, timeout=60):
    return subprocess.check_output(ADB + ['shell', command], text=True, timeout=timeout)

def read_remote(path):
    return subprocess.check_output(ADB + ['exec-out', 'cat', path])

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def temperatures():
    text = shell('dumpsys thermalservice')
    live = text.split('Current temperatures from HAL:', 1)[-1].split('Current cooling devices', 1)[0]
    data = {name: float(temp) for temp, name in re.findall(r'mValue=([\d.]+), mType=\d+, mName=([^,]+)', live)}
    match = re.search(r'^Thermal Status: (\d+)', text, re.M)
    return {'status': int(match[1]) if match else None, 'celsius': data}, text

def cool():
    start = time.monotonic()
    while True:
        data, raw = temperatures()
        if data['status'] == 0 and data['celsius'].get('AP', 100) <= 34 and data['celsius'].get('SKIN', 100) <= 35.5:
            return data, raw
        if time.monotonic() - start > 600:
            raise RuntimeError('Phone did not reach the documented start temperature')
        print(json.dumps({'waiting_for_cooldown': data}), flush=True)
        time.sleep(15)

ps = shell('ps -A')
assert not any(name in ps for name in ['nntr_causallm', 'quick_dot_ai_test', ':quickai_native']), 'Device busy'
shell('mkdir -p ' + shlex.quote(RUNTIME) + ' ' + shlex.quote(REMOTE + '/common'))
for name in LIBS + ['nntr_causallm']:
    shell('cp ' + shlex.quote(SOURCE_RUNTIME + '/' + name) + ' ' + shlex.quote(RUNTIME + '/' + name))
shell('chmod 755 ' + shlex.quote(RUNTIME + '/nntr_causallm'))
for name in ['config.json', 'generation_config.json', 'tokenizer.json', 'tokenizer_config.json',
             'chat_template.jinja', 'rotation_signs.json', 'act_scales.json']:
    shell('cp ' + shlex.quote(PACK + '/' + name) + ' ' + shlex.quote(REMOTE + '/common/' + name))
config_bytes = read_remote(PACK + '/nntr_config.json')
generation_bytes = read_remote(PACK + '/generation_config.json')
config = json.loads(config_bytes)
(OUT / 'deployed-nntr_config.json').write_bytes(config_bytes)
(OUT / 'deployed-generation_config.json').write_bytes(generation_bytes)
(OUT / 'deployed-config.json').write_bytes(read_remote(PACK + '/config.json'))
pkg = shell('pm path com.example.quickdotaiapp').strip().split(':', 1)[1]
apk_lib = pkg.rsplit('/', 1)[0] + '/lib/arm64'
runtime_hashes = {}
for name in LIBS:
    deployed = shell('sha256sum ' + shlex.quote(RUNTIME + '/' + name)).split()[0]
    installed = shell('sha256sum ' + shlex.quote(apk_lib + '/' + name)).split()[0]
    assert deployed == installed, 'App/runtime library mismatch: ' + name
    runtime_hashes[name] = deployed
runtime_hashes['nntr_causallm'] = shell('sha256sum ' + shlex.quote(RUNTIME + '/nntr_causallm')).split()[0]
weight = PACK + '/' + config['model_file_name']
manifest = {
    'created_utc': datetime.now(timezone.utc).isoformat(), 'device': 'Galaxy S26 Ultra SM-S948U',
    'soc': shell('getprop ro.soc.model').strip(), 'android': shell('getprop ro.build.version.release').strip(),
    'page_size': int(shell('getconf PAGE_SIZE')), 'model_pack': PACK,
    'weight_file': config['model_file_name'], 'weight_bytes': int(shell('stat -c %s ' + shlex.quote(weight))),
    'weight_sha256': shell('sha256sum ' + shlex.quote(weight)).split()[0],
    'runtime_source': SOURCE_RUNTIME, 'runtime_sha256': runtime_hashes,
    'all_seven_libraries_match_installed_apk': True,
    'guide_reference_commit': 'fa078c94d1d73609c5584e948931384d69f9364c',
    'runtime_source_commit_verified': False,
    'remote_directory': REMOTE, 'threads': 8, 'total_output_tokens': 128,
    'decode_steps': 127, 'repeats': 3,
    'input_lengths': [1024, 2048, 4096, 8192],
    'warmup': 'one excluded 1024-input/128-output run',
    'start_temperature_limits_c': {'AP': 34, 'SKIN': 35.5},
    'cooldown_minimum_seconds': 15,
    'notes': 'Fresh CLI processes; normal OS caches, no cache flush; USB connected. Deployed weights and files unchanged.',
    'overrides': {'num_to_generate': 127, 'bad_word_ids': [1, 50, 106], 'do_sample': False,
                  'sample_input': 'exact-token synthetic report prompt', 'htp.token_trace': 'per-run trace path'},
}
save('manifest.json', manifest)
rows = []

def run(length, repeat, warmup=False):
    tag = f'p{length}-' + ('warmup' if warmup else f'r{repeat}')
    before, raw_before = cool()
    (OUT / (tag + '-thermal-before.txt')).write_text(raw_before)
    model = REMOTE + '/' + tag
    shell('mkdir -p ' + shlex.quote(model))
    for name in ['config.json', 'tokenizer.json', 'tokenizer_config.json', 'chat_template.jinja',
                 'rotation_signs.json', 'act_scales.json']:
        shell('ln -s ' + shlex.quote(REMOTE + '/common/' + name) + ' ' + shlex.quote(model + '/' + name))
    cfg = json.loads(config_bytes)
    cfg['model_file_name'] = weight
    cfg['num_to_generate'] = 127
    cfg['bad_word_ids'] = sorted(set(cfg.get('bad_word_ids', []) + [1, 50, 106]))
    cfg['sample_input'] = (OUT / f'prompt-{length}.txt').read_text()
    cfg['htp'] = dict(cfg.get('htp') or {}, token_trace=model + '/trace.json')
    generation = json.loads(generation_bytes)
    generation['do_sample'] = False
    save(tag + '-nntr_config.json', cfg)
    save(tag + '-generation_config.json', generation)
    for local, target in [(tag + '-nntr_config.json', 'nntr_config.json'),
                          (tag + '-generation_config.json', 'generation_config.json')]:
        subprocess.run(ADB + ['push', str(OUT / local), model + '/' + target], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    env = {'LD_LIBRARY_PATH': RUNTIME, 'ADSP_LIBRARY_PATH': RUNTIME,
           'NNTR_NUM_THREADS': '8', 'NNTR_ENGINE': 'cpu', 'NNTR_GENERATED_IDS': model + '/generated.ids'}
    command = 'cd ' + shlex.quote(model) + ' && env ' + shlex.join([k+'='+v for k,v in env.items()])
    command += ' timeout 600 ' + shlex.join([RUNTIME + '/nntr_causallm', model])
    print(json.dumps({'starting': tag, 'thermal': before}), flush=True)
    start = time.monotonic()
    with (OUT / (tag + '.log')).open('wb') as logfile:
        process = subprocess.run(ADB + ['shell', command], stdout=logfile, stderr=subprocess.STDOUT, timeout=630)
    elapsed = time.monotonic() - start
    after, raw_after = temperatures()
    (OUT / (tag + '-thermal-after.txt')).write_text(raw_after)
    log = (OUT / (tag + '.log')).read_text(errors='replace')
    row = {'tag': tag, 'input_requested': length, 'repeat': repeat, 'warmup': warmup,
           'returncode': process.returncode, 'process_seconds': elapsed,
           'thermal_before': before, 'thermal_after': after, 'command': command}
    for key, pattern in [('prefill', r'prefill: (\d+) tokens, ([\d.]+) ms, ([\d.]+) TPS'),
                         ('decode', r'generation: (\d+) tokens, ([\d.]+) ms, ([\d.]+) TPS')]:
        m = re.search(pattern, log)
        if m:
            row.update({key+'_tokens': int(m[1]), key+'_ms': float(m[2]), key+'_tps': float(m[3])})
    for key, pattern in [('peak_memory_kib', r'peak memory: (\d+) KB'),
                         ('honest_peak_kib', r'honest RssAnon\+accel: (\d+) KB'),
                         ('ru_maxrss_kib', r'ru_maxrss: (\d+) KB')]:
        m = re.search(pattern, log)
        if m: row[key] = int(m[1])
    split = re.search(r'\[PERF-SPLIT\] ([^\n]+)', log)
    if split:
        row['perf_split'] = {k: float(v) for k,v in re.findall(r'(\w+)=([\d.]+)', split[1])}
    row['htp_resident_graph'] = 'resident=RMSNORM|FC|QK_NORM|ROPE|ATTN_M1|ADD|ROUTER_TOPK|MOE|DENSE_FFN|LM_HEAD' in log
    row['cpu_fallback'] = bool(re.search(r'CPU fallback|falling back to CPU', log, re.I))
    if process.returncode == 0:
        trace_raw = read_remote(model + '/trace.json');trace = json.loads(trace_raw)
        (OUT / (tag + '-trace.json')).write_bytes(trace_raw)
        expected = json.loads((OUT / f'input-{length}.json').read_text())
        row['input_ids_match'] = trace['input_ids'] == expected
        row['actual_input_tokens'] = len(trace['input_ids'])
        row['actual_output_tokens'] = len(trace['output_ids'])
        row['output_ids_sha256'] = digest(json.dumps(trace['output_ids']).encode())
    rows.append(row);save('results.json', rows)
    print(json.dumps(row), flush=True)
    assert process.returncode == 0, tag + ': CLI failed'
    assert row.get('input_ids_match') and row.get('prefill_tokens') == length, tag + ': input truncated or tokenizer mismatch'
    assert row.get('actual_output_tokens') == 128 and row.get('decode_tokens') == 127, tag + ': output length mismatch'
    assert row['htp_resident_graph'] and not row['cpu_fallback'], tag + ': NPU graph not confirmed'
    time.sleep(15)

run(1024, 0, warmup=True)
for repeat, lengths in enumerate([[1024,2048,4096,8192], [8192,4096,2048,1024], [1024,4096,2048,8192]], 1):
    for length in lengths: run(length, repeat)
summary = []
for length in manifest['input_lengths']:
    selected = [r for r in rows if not r['warmup'] and r['input_requested'] == length]
    result = {'input_tokens': length, 'output_tokens': 128, 'runs': len(selected),
              'output_ids_identical': len({r['output_ids_sha256'] for r in selected}) == 1}
    for key in ['prefill_tps','prefill_ms','decode_tps','decode_ms','peak_memory_kib','honest_peak_kib']:
        values = [r[key] for r in selected]
        result[key] = {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
    for key in ['ttft_ms','first_token_ms','steady_ms','e2e_ms']:
        values = [r['perf_split'][key] for r in selected]
        result[key] = {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
    summary.append(result)
save('summary.json', summary)
assert read_remote(PACK + '/nntr_config.json') == config_bytes
assert read_remote(PACK + '/generation_config.json') == generation_bytes
print(json.dumps({'finished': summary}), flush=True)
