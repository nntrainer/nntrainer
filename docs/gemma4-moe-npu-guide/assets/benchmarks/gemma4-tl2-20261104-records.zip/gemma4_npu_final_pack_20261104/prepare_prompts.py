from pathlib import Path
import argparse
import json,hashlib
from tokenizers import Tokenizer
parser=argparse.ArgumentParser(description='Generate the benchmark prompts using the deployed tokenizer.')
parser.add_argument('--tokenizer', required=True)
args=parser.parse_args()
out=Path(__file__).resolve().parent
tok=Tokenizer.from_file(args.tokenizer)
paragraphs=[
'The city research team studied how public libraries help residents learn new skills. Librarians organized reading groups, computer workshops, and quiet study sessions. Visitors described reliable opening hours and clear signs as the most useful improvements. The team recorded attendance each week and compared the results with the previous season.',
'A neighborhood garden provided another example of shared resources. Volunteers planted vegetables, repaired water pipes, and kept records of rainfall. Local students measured soil moisture and wrote short reports about their observations. The project succeeded when participants agreed on a regular schedule and explained their responsibilities to new members.',
'The transport group examined journeys between homes, schools, and workplaces. Frequent buses made daily travel more predictable, while safe crossings helped people reach the stops. Researchers collected anonymous counts rather than individual travel histories. They recommended small changes that could be evaluated before wider investment.',
'Energy planning focused on simple maintenance and careful measurement. Technicians checked building insulation, lighting controls, and ventilation schedules. They compared electricity use across weeks with similar weather. The report distinguished the cost of new equipment from the savings that appeared after installation.',
'Across the projects, the investigators emphasized transparent records and repeatable methods. Each group documented its assumptions, limitations, and unexpected outcomes. Residents reviewed the findings at an open meeting and suggested practical next steps. The final report connected local knowledge with measurements collected over time.'
]
body='\n\n'.join(paragraphs*60)
body_ids=tok.encode(body,add_special_tokens=False).ids
prefix='<bos><|turn>user\nRead the following report and summarize its main findings in English.\n\n<report>\n'
suffix='\n</report>\nWrite a detailed summary of the report.<turn|>\n<|turn>model\n<|channel>thought\n<channel|>'
rows=[]
for length in [1024,2048,4096,8192]:
 count=length-80
 report=tok.decode(body_ids[:count],skip_special_tokens=False)
 for padding in range(120):
  text=prefix+report+(' a'*padding)+suffix
  ids=tok.encode(text,add_special_tokens=True).ids
  if len(ids)==length:break
 else:raise RuntimeError(f'Cannot make exact prompt {length}')
 (out/f'prompt-{length}.txt').write_text(text)
 (out/f'input-{length}.json').write_text(json.dumps(ids))
 rows.append({'input_tokens':length,'characters':len(text),'sha256':hashlib.sha256(text.encode()).hexdigest()})
print(json.dumps(rows,indent=2))
(out/'prompts.json').write_text(json.dumps(rows,indent=2)+'\n')
