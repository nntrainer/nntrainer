# Deployed Gemma4 TL2 NPU benchmark — 2026-11-04

Actual CLI measurements on Galaxy S26 Ultra SM-S948U (SM8850, Android 16,
4 KB pages). Inputs are exactly 1,024, 2,048, 4,096 and 8,192 tokens; each run
generates exactly 128 output token IDs. Results use three independent CLI
processes per length, after one excluded 1K warm-up.

## Model and runtime identity

The deployed pack is
`/sdcard/Download/aistudio-mobile/models/gemma4-26b-a4b-htp-w4a32`.
It has rotated `TL2CX_WH` experts, `QS4CX_WH_AFFINE` projections/LM head,
and `Q4_0` embeddings. This is not a uniformly TL2 model.

- Weight: `nntr_gemma4_26b_a4b_tl2_rotated.bin`
- Size: 6,604,561,848 bytes
- SHA-256: `d119366443812958d5c380b8c6b0e2ba0a0f65b93d4621e1e0484116919b30e7`
- Runtime source on the phone: `/data/local/tmp/v4480_sync_1104/fix`
- All seven `.so` files were checked against the installed Quick.AI APK and
  matched by SHA-256. `manifest.json` records every hash, including the CLI.

The guide references PR #4480 at `fa078c94d1d73609c5584e948931384d69f9364c`.
The deployed binary's source commit was not independently established; this
dataset identifies the measured binaries by hash and does not claim a fresh
build of that commit.

## Method

`run.py` preserves deployed settings, including `init_seq_len=2048`,
`max_seq_len=8704`, `attention_kv_dtype=q8`, `moe_cache_experts=16`, and
`moe_decode_prefetch=true`. Each trial uses an isolated config directory,
the same original weight file, a snapshot of the installed runtime, greedy
decoding, and `NNTR_NUM_THREADS=8`. `NNTR_ENGINE=cpu` is the host default;
explicit HTP engine settings in the model config select NPU execution.
Every log confirms the resident HTP graph, including attention, MoE and LM head.

Only benchmark copies change `sample_input`, `num_to_generate=127`,
`bad_word_ids=[1,50,106]`, `htp.token_trace`, and `do_sample=false`.
The weight path is made absolute. The original pack and app settings are
unchanged. Suppressing EOS is needed for fixed-length output; it is not a
recommended normal-chat setting.

Prefill selects the first output token. The CLI's 127 decode iterations then
make **128 total tokens**. For each run, the harness asserts exact input ID
equality with the expected tokenizer output, 128 native output IDs, 127 CLI
decode steps, a successful exit and the resident NPU graph. It checks the
original deployed configuration files are unchanged after the sweep.

The synthetic English report repeats five original paragraphs about libraries,
gardening, transport, energy and measurement. A small ` a` padding suffix
makes exact input lengths possible. Counts include BOS and chat-template
tokens, using the deployed tokenizer with `tokenizers==0.22.1`. The native
runtime's input IDs must match these IDs, not just their count. Actual prompts
and expected IDs are included. This is a throughput test, not an accuracy test.

Run order:

1. Excluded warm-up: 1K.
2. Pass 1: 1K, 2K, 4K, 8K.
3. Pass 2: 8K, 4K, 2K, 1K.
4. Pass 3: 1K, 4K, 2K, 8K.

The phone was USB-connected. OS caches were not flushed. Each trial starts
after at least 15 seconds of rest and only when live HAL readings report
thermal status 0, AP ≤34 °C and skin ≤35.5 °C. Before/after readings are saved;
these short cooled trials do not establish sustained hot-device performance.

## Metrics and records

- `summary.json`: median/min/max for each length; warm-up excluded.
- `results.json` and `runs.csv`: individual trials, including marked warm-up.
- `*.log`: complete CLI stdout/stderr.
- `*-trace.json`: native input and output token IDs.
- `*-nntr_config.json`, `*-generation_config.json`: exact trial settings.
- `*-thermal-before.txt`, `*-thermal-after.txt`: raw `dumpsys thermalservice`.
- `deployed-*.json`: unchanged original pack settings.
- `manifest.json`, `prompts.json`: identities, conditions and prompt hashes.
- `run.py`, `prepare_prompts.py`: measurement and prompt-generation scripts.

Prefill TPS and decode TPS are the CLI's values. Decode TPS is 127 divided by
generation seconds, including the first decode step. TTFT is the native
`[PERF-SPLIT] ttft_ms` and excludes model load and process startup.
`first_token_ms` in that line is the first **decode step**, not TTFT.
Peak memory is sampled `RssAnon + accelerator`, excluding file-backed page
cache. Values labelled `KB` by the runtime are KiB; divide by 1,048,576 for
GiB. This is not total device RAM use or model storage size.

## Repeat the measurement

Use a separate copy of this directory so the recorded results remain intact.
In that copy, set `ADB`, `PACK` and `SOURCE_RUNTIME` near the top of `run.py`
to the target phone and matching deployed artifacts. The script requires
`adb`, Python 3, the pack files and an installed Quick.AI APK whose native
libraries match the selected runtime. It creates a unique device directory
and writes new host results beside itself.

The supplied prompts can be reused directly. To regenerate them from the
matching deployed tokenizer, install `tokenizers==0.22.1` in a Python virtual
environment and run `prepare_prompts.py --tokenizer /path/to/tokenizer.json`
in the copied directory. This rewrites the prompt and expected-ID files.

Unload the app's model and stop other inference on the target phone. Run
`python3 run.py` from the copied directory and wait for its `finished` record.
Do not combine results from different model weights, binaries or settings.
Weights, tokenizer files and native binaries are not distributed in this
record archive; obtain the matching model pack and runtime separately.
